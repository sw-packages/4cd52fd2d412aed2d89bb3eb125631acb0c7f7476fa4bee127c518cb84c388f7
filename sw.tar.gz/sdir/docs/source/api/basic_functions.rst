.. Copyright (c) 2016--2018 Keith O'Hara

   Distributed under the terms of the Apache License, Version 2.0.

   The full license is in the file LICENSE, distributed with this software.

Basic functions
===============

.. _abs-function-reference:
.. doxygenfunction:: abs(const T)
   :project: gcem

.. _exp-function-reference:
.. doxygenfunction:: exp(const T)
   :project: gcem

.. _factorial-func-ref:
.. doxygenfunction:: factorial(const T)
   :project: gcem

.. _log-function-reference:
.. doxygenfunction:: log(const T)
   :project: gcem

.. _max-function-reference:
.. doxygenfunction:: max(const T1, const T2)
   :project: gcem

.. _min-function-reference:
.. doxygenfunction:: min(const T1, const T2)
   :project: gcem

.. _pow-function-reference:
.. doxygenfunction:: pow(const T1, const T2)
   :project: gcem

.. _sgn-function-reference:
.. doxygenfunction:: sgn(const T)
   :project: gcem

.. _sqrt-function-reference:
.. doxygenfunction:: sqrt(const T)
   :project: gcem
