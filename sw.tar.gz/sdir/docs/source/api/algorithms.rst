.. Copyright (c) 2016--2018 Keith O'Hara

   Distributed under the terms of the Apache License, Version 2.0.

   The full license is in the file LICENSE, distributed with this software.

Algorithms
===============

.. _gcd-function-reference:
.. doxygenfunction:: gcd(const T1, const T2)
   :project: gcem

.. _lcm-function-reference:
.. doxygenfunction:: lcm(const T1, const T2)
   :project: gcem
